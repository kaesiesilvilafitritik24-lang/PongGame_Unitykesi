using UnityEngine;

public class GoalZone : MonoBehaviour
{
    [SerializeField] private bool isPlayer1Goal; // Centang di Outzone Kiri
    private GameManager manager;

    void Start() => manager = Object.FindFirstObjectByType<GameManager>();

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Ball"))
        {
            // Jika bola masuk gawang kiri, poin buat lawan (kanan)
            manager.AddScore(!isPlayer1Goal);
        }
    }
}