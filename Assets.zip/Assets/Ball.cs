using UnityEngine;

public class Ball : MonoBehaviour
{
    [SerializeField] private float speed = 12f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Invoke("Launch", 1f);
    }

    public void Launch()
    {
        rb.linearVelocity = Vector2.zero;
        transform.position = Vector2.zero;

        float x = Random.Range(0, 2) == 0 ? -1 : 1;
        float y = Random.Range(-0.5f, 0.5f);
        rb.linearVelocity = new Vector2(x, y).normalized * speed;
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.CompareTag("Player") || col.gameObject.CompareTag("Opponent"))
        {
            float y = (transform.position.y - col.transform.position.y) / col.collider.bounds.size.y;
            float x = (col.gameObject.CompareTag("Player")) ? 1 : -1;
            rb.linearVelocity = new Vector2(x, y).normalized * speed;
        }
    }
}