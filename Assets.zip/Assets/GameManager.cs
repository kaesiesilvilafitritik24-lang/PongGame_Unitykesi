using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    // Kita pakai 'GameObject' supaya Unity mau menerima tarikan objeknya
    public GameObject ballObject; 
    public TMP_Text PlayerText;
    public TMP_Text OpponentText;

    private int score1;
    private int score2;

    public void AddScore(bool isPlayer1)
    {
        if (isPlayer1)
        {
            score1++;
            if (PlayerText != null) PlayerText.text = score1.ToString();
        }
        else
        {
            score2++;
            if (OpponentText != null) OpponentText.text = score2.ToString();
        }

        if (score1 >= 11 || score2 >= 11)
        {
            score1 = 0;
            score2 = 0;
            if (PlayerText != null) PlayerText.text = "0";
            if (OpponentText != null) OpponentText.text = "0";
        }

        // Memanggil fungsi Launch di script Ball
        if (ballObject != null)
        {
            ballObject.GetComponent<Ball>().Launch();
        }
    }
}