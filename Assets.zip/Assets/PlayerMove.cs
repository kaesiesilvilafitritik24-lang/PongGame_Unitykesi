using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    [SerializeField] private float speed = 10f;
    [SerializeField] private bool isAI = false;
    [SerializeField] private Transform ball;
    private Rigidbody2D rb;

    void Start() => rb = GetComponent<Rigidbody2D>();

    void FixedUpdate()
    {
        if (isAI) {
            if (ball == null) return;
            float dir = (ball.position.y > transform.position.y + 0.2f) ? 1 : (ball.position.y < transform.position.y - 0.2f) ? -1 : 0;
            rb.linearVelocity = new Vector2(0, dir * speed * 0.8f);
        } else {
            float move = 0;
            if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) move = 1;
            else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) move = -1;
            rb.linearVelocity = new Vector2(0, move * speed);
        }
    }
}